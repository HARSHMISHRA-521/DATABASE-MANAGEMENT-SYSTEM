<?php
$flag = 0;
session_start();
$owner_id = $_SESSION['owner_id'];
// $c_id = $_SESSION['c_id'];
if(isset($_POST['add']))
{
$conn = mysqli_connect("localhost","root","","movie_ticket");
if(!$conn)
{
    die("conection failed !!!".mysqli_connect_error());
}

$city = $_POST['city'];
$type = $_POST['type'];
$movie_name = $_POST['movie_name'];
$price = $_POST['price'];
$rating = $_POST['rating'];

if(isset($_POST['add']))
{
    
    $sql_query = "INSERT INTO `movie` (`owner_id`, `city`,`movie_name`, `DOP`,`price`,`rating`,`type`) VALUES ('$owner_id', '$city', '$movie_name',current_timestamp(),'$price', '$rating','$type');";
    mysqli_query($conn,$sql_query);
    $flag =1;
    echo"<script> alert('Added successfully')</script>";
    mysqli_close($conn);
}
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="provide_theatre.css">
    <title>Customer main page</title>
</head>

<body style="background-image : url('bgg5.jpg'); background-size : cover; background-repeat : no-repeat;  backdrop-filter: blur(5px);">

    <div class="center" style="left:70%;top:50%;background:lightblue;border:none">
        <h1 style = "color:lightblue;font-size:xx-large;background:darkblue">Add a Show</h1>
        <div class="failed">
            <span>
                <?php
                    if($flag==1)
                    {
                        // echo"Added successfully!!!";
                    }
                ?>
            </span>

        </div>
        <form action="http://localhost/covid/add_movie.php" method="POST">

            <!-- <div class="selectlocation">
                <span class="label">CITY: </span>
                <select name="city" id="">
                    <option value="Bangalore">Bangalore</option>
                    <option value="Chennai">Chennai</option>
                    <option value="Mumbai">Mumbai</option>
                    <option value="Hyderabad">Hyderabad</option>
                </select>
            </div> -->


            <!-- <div class="selectvehicle">
                <span class="label">TYPE: </span>
                <select name="type" id="">
                    <option value="car">car</option>
                    <option value="bike">bike</option>
                    <option value="Cycle">Cycle</option>
                </select>
            </div> -->
            <div class="flex justify-center">
            <span class="label" style = "justify-content: center;display: flex;font-size: large;font-weight: bold;" >CITY </span>
                <div class="mb-3 xl:w-96">
                    <select class="form-select appearance-none
                                    block
                                    w-full
                                    px-3
                                    py-1.5
                                    text-base
                                    font-normal
                                    text-gray-700
                                     bg-white bg-clip-padding bg-no-repeat
                                    border border-solid border-gray-300
                                    rounded
                                    transition
                                    ease-in-out
                                    m-0
                                    focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" aria-label="Default select example" name="city">
                        <option value="Bangalore">Bangalore</option>
                        <option value="Chennai">Chennai</option>
                        <option value="Mumbai">Mumbai</option>
                        <option value="Hyderabad">Hyderabad</option>
                        <option value="Delhi">Delhi</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-center">
            <span class="label" style = "justify-content: center;display: flex;font-size: large;font-weight: bold;" >Event Host </span>
                <div class="mb-3 xl:w-96">
                    <select class="form-select appearance-none
                                    block
                                    w-full
                                    px-3
                                    py-1.5
                                    text-base
                                    font-normal
                                    text-gray-700
                                     bg-white bg-clip-padding bg-no-repeat
                                    border border-solid border-gray-300
                                    rounded
                                    transition
                                    ease-in-out
                                    m-0
                                    focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" aria-label="Default select example" name="type">
                        <option value="the laughter">the laughter</option>
                        <option value="the laugh club">the laugh club</option>
                        <option value="the comedy club">the comedy club</option>
                        <option value="raiyan">raiyan</option>
                        <option value="H club">H club</option>
                        <option value="xyz">xyz</option>
                    </select>
                </div>
            </div>
            
            <div class="text_field">
                <input type="text"  required name="movie_name">
                <span></span>
                <label style="color:black">Show Name</label>
            </div>

            <div class="text_field">
                <input type="text"  required name="rating">
                <span></span>
                <label style="color:black">Feature(ft. )</label>
            </div>

            <div class="text_field">
                <input type="text"  required name="price">
                <span></span>
                <label style="color:black">Price</label>
            </div>
            
            <input type="submit" name="add" value="ADD" style="background:darkblue">
    </div>
    </form>
    </div>
</body>

</html>